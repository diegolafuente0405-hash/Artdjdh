// Service worker: guarda todo en caché para que la app funcione sin internet.
// Al cambiar archivos, sube el número de VERSION.
const VERSION = 'escalas-v3';
const FILES = [
  "./",
  "index.html",
  "styles.css",
  "manifest.webmanifest",
  "icons/icon.svg",
  "icons/icon-192.png",
  "icons/icon-512.png",
  "src/app.js",
  "src/audio.js",
  "src/staff.js",
  "src/theory.js",
  "src/state.js",
  "samples/m52.mp3",
  "samples/m53.mp3",
  "samples/m55.mp3",
  "samples/m56.mp3",
  "samples/m57.mp3",
  "samples/m58.mp3",
  "samples/m59.mp3",
  "samples/m60.mp3",
  "samples/m61.mp3",
  "samples/m62.mp3",
  "samples/m63.mp3",
  "samples/m64.mp3",
  "samples/m65.mp3",
  "samples/m67.mp3",
  "samples/m68.mp3",
  "samples/m69.mp3",
  "samples/m70.mp3",
  "samples/m71.mp3",
  "samples/m72.mp3",
  "samples/m73.mp3",
  "samples/m74.mp3",
  "samples/m75.mp3",
  "samples/m76.mp3",
  "samples/m77.mp3",
  "samples/m78.mp3",
  "samples/m79.mp3",
  "samples/m80.mp3",
  "samples/m81.mp3",
  "samples/m82.mp3",
  "samples/m83.mp3",
  "samples/m84.mp3",
  "samples/m85.mp3",
  "samples/m86.mp3",
  "samples/m87.mp3",
  "samples/m88.mp3"
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  if (e.request.method !== 'GET') return;
  e.respondWith(caches.match(e.request).then((hit) => hit || fetch(e.request)));
});
