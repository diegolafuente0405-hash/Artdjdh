// Ajustes actuales de la práctica.
export const S = {
  type: 'major',   // major | minor | harm | mel | chrom | arpM | arpm
  pc: 0,           // 0 = Do ... 11 = Si
  dir: 'both',     // up | down | both
  fig: 'q',        // q = negras, e = corcheas
  oct: 1,
  hi: '0',         // '1' = una octava arriba
  bpm: 80,
  trumpet: true,
  metro: true,
  count: true,
  loop: false,
  play: false,     // modo Tocar: puntúa tus pistones
  hint: true,      // mostrar digitación objetivo
};
