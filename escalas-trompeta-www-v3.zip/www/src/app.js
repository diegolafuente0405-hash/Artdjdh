// Interfaz y reproductor: une teoría, pentagrama y audio.
import { S } from './state.js';
import { buildNotes, layout, fingering, writtenName, soundName, isMinorish, MIN_LABELS, MAJ_LABELS } from './theory.js';
import { renderStaff, K } from './staff.js';
import { initAudio, playNote, click, stopAll, now } from './audio.js';

const $ = (s) => document.querySelector(s);
let song = { items: [], total: 0, cycle: 4 }, cur = -1;
const P = { playing: false, t0: 0, spb: 0.75, sb: 0, ci: 4, timer: 0, raf: 0 };
const timeOf = (b) => P.t0 + b * P.spb;
let target = [], pressed = new Set(), grades = [], acc = [], lastC = 0;
const best = (() => { try { return JSON.parse(localStorage.getItem('best') || '{}'); } catch (e) { return {}; } })();
const same = (a) => { const f = fingering(a.midi); return f.length === pressed.size && f.every(n => pressed.has(n)); };
const grade = (k) => { const q = acc[k]; return q && q.t && q.m / q.t >= 0.6 ? 'hit' : 'miss'; };

/* ---------- partitura ---------- */
function render() {
  const notes = buildNotes(S), L = layout(notes, S);
  const items = renderStaff(notes, L);
  song = { items, total: L.total, cycle: L.cycle };
  cur = -1; showIdle(); drawGrid();
}

/* ---------- vista: pistones y lectura ---------- */
function pistons(f) { target = f; drawP(); }
function drawP() {
  const d = S.play ? [...pressed] : target, lit = S.play ? (S.hint && P.playing ? target : []) : target;
  [1, 2, 3].forEach(n => { $('#p' + n).classList.toggle('down', d.includes(n)); $('#n' + n).classList.toggle('lit', lit.includes(n)); });
}
function showIdle() {
  setCurrent(-1);
  document.querySelectorAll('#beats i').forEach(i => i.className = '');
  const a = song.items[0];
  $('#rnote').firstChild.nodeValue = a ? writtenName(a.letter, a.acc, a.step) : '';
  $('#rsound').textContent = a ? '· primera nota' : '';
  $('#rfing').innerHTML = 'Pulsa ▶ para empezar';
  pistons([]);
  $('#sheet').scrollLeft = 0;
}
function setCurrent(i) {
  if (i === cur) return;
  if (S.play && P.playing) for (let k = Math.max(cur, 0); k < i; k++) grades[k] = grade(k);
  cur = i;
  document.querySelectorAll('.note').forEach((e, k) =>
    e.setAttribute('class', i < 0 ? 'note' : k < i ? 'note ' + (S.play && grades[k] ? grades[k] : 'done') : k === i ? 'note on' : 'note'));
  if (i < 0) return;
  const a = song.items[i];
  $('#rnote').firstChild.nodeValue = writtenName(a.letter, a.acc, a.step);
  $('#rsound').textContent = '· suena ' + soundName(a.midi);
  const f = fingering(a.midi);
  pistons(f);
  $('#rfing').innerHTML = f.length ? 'Pistones <b>' + f.join(' · ') + '</b>' : '<b>Al aire</b> (sin pistones)';
}
function setPlayIcon(on) {
  $('#playicon').setAttribute('d', on ? 'M6 5h4.2v14H6zM13.8 5H18v14h-4.2z' : 'M7 4.5v15l13-7.5z');
  $('#play').setAttribute('aria-label', on ? 'Detener' : 'Reproducir');
}

/* ---------- reproductor ---------- */
function schedule() {
  const horizon = now() + 0.18;
  while (timeOf(P.sb) < horizon) {
    const b = P.sb;
    if (!S.loop && b >= song.cycle) { P.sb++; continue; }
    if (S.metro) click(timeOf(b), ((b % 4) + 4) % 4 === 0);
    if (b >= 0 && S.trumpet && !S.play) {
      const c = Math.floor(b / song.cycle), local = b - c * song.cycle;
      song.items.forEach(a => {
        if (a.start >= local - 1e-9 && a.start < local + 1 - 1e-9)
          playNote(a.midi - 2, timeOf(b + (a.start - local)), a.d * P.spb);
      });
    }
    P.sb++;
  }
}
async function start() {
  if (P.playing) return;
  try { await initAudio(t => $('#msg').textContent = t); }
  catch (e) { $('#msg').textContent = 'No se pudo iniciar el audio en este navegador.'; return; }
  P.spb = 60 / S.bpm; P.ci = S.count ? 4 : 0;
  P.t0 = now() + 0.12 + P.ci * P.spb;
  P.sb = -P.ci; P.playing = true; grades = []; acc = []; lastC = 0; drawP();
  setPlayIcon(true);
  P.timer = setInterval(schedule, 25); schedule();
  cancelAnimationFrame(P.raf); P.raf = requestAnimationFrame(frame);
}
function stop() {
  P.playing = false; clearInterval(P.timer); cancelAnimationFrame(P.raf);
  stopAll(); setPlayIcon(false); showIdle();
}
function frame() {
  if (!P.playing) return;
  const pos = (now() - P.t0) / P.spb;
  const bi = ((Math.floor(pos) % 4) + 4) % 4;
  document.querySelectorAll('#beats i').forEach((e, k) => e.className = k === bi ? ('on' + (k === 0 ? ' first' : '')) : '');
  if (pos < 0) {
    $('#rfing').innerHTML = 'Cuenta previa… <b>' + (Math.floor(pos) + P.ci + 1) + '</b>';
  } else if (!S.loop && pos >= song.cycle) {
    finish(); return;
  } else {
    const local = pos - Math.floor(pos / song.cycle) * song.cycle, c0 = Math.floor(pos / song.cycle);
    if (c0 !== lastC) { lastC = c0; grades = []; acc = []; cur = -1; }
    const idx = song.items.findIndex(a => local >= a.start - 1e-6 && local < a.start + a.d);
    if (idx >= 0) {
      if (S.play) { const a = song.items[idx]; if (local >= a.start + Math.min(0.25, a.d * 0.3)) { const q = acc[idx] || (acc[idx] = { t: 0, m: 0 }); q.t++; if (same(a)) q.m++; } }
      setCurrent(idx);
      const sh = $('#sheet'), target = song.items[idx].cx * K - sh.clientWidth * 0.4;
      sh.scrollLeft += (target - sh.scrollLeft) * 0.18;
    }
  }
  P.raf = requestAnimationFrame(frame);
}
function finish() {
  const n = song.items.length;
  for (let k = 0; k < n; k++) grades[k] = grade(k);
  const h = grades.filter(g => g === 'hit').length, pct = Math.round(100 * h / n), play = S.play;
  stop();
  if (!play) return;
  document.querySelectorAll('.note').forEach((e, k) => e.setAttribute('class', 'note ' + grades[k]));
  const stars = pct >= 90 ? 3 : pct >= 75 ? 2 : pct >= 50 ? 1 : 0, key = S.type + S.pc;
  if (stars > (best[key] || 0)) { best[key] = stars; try { localStorage.setItem('best', JSON.stringify(best)); } catch (e) {} }
  drawGrid();
  $('#msg').innerHTML = '<b>' + pct + '%</b> · ' + '★'.repeat(stars) + '☆'.repeat(3 - stars) + ' · ' + h + '/' + n + ' notas';
}
function drawGrid() {
  const L = isMinorish(S.type) ? MIN_LABELS : MAJ_LABELS;
  $('#grid').innerHTML = L.map((t, i) => { const s = best[S.type + i] || 0; return `<button data-i="${i}" aria-pressed="${i === S.pc}">${t}<small>${'★'.repeat(s) + '☆'.repeat(3 - s)}</small></button>`; }).join('');
  $('#grid').querySelectorAll('button').forEach(b => b.onclick = () => { S.pc = +b.dataset.i; $('#root').value = S.pc; refresh(); });
}
function setBpm(v) {
  v = Math.max(40, Math.min(208, Math.round(v)));
  if (P.playing) { const pos = (now() - P.t0) / P.spb; P.spb = 60 / v; P.t0 = now() - pos * P.spb; }
  S.bpm = v; $('#bpm').value = v; $('#bpmv').textContent = v;
}

/* ---------- controles ---------- */
function fillRoots() {
  const minor = isMinorish(S.type), labels = minor ? MIN_LABELS : MAJ_LABELS;
  const suffix = minor ? ' menor' : (S.type === 'chrom' || S.type.startsWith('arp') || ['dor','phr','lyd','mix','loc'].includes(S.type)) ? '' : ' mayor';
  $('#root').innerHTML = labels.map((t, i) => `<option value="${i}">${t}${suffix}</option>`).join('');
  $('#root').value = S.pc;
}
const refresh = () => { if (P.playing) stop(); render(); };

$('#type').onchange = e => { S.type = e.target.value; fillRoots(); refresh(); };
$('#root').onchange = e => { S.pc = +e.target.value; refresh(); };
document.querySelectorAll('.seg').forEach(seg => {
  const key = seg.dataset.key, btns = seg.querySelectorAll('button');
  const sync = () => btns.forEach(b => b.setAttribute('aria-pressed', String(String(S[key]) === b.dataset.v)));
  btns.forEach(b => b.onclick = () => { S[key] = key === 'oct' ? +b.dataset.v : b.dataset.v; sync(); refresh(); });
  sync();
});
function toggle(id, key) {
  const b = $(id);
  b.onclick = () => { S[key] = !S[key]; b.setAttribute('aria-pressed', String(S[key])); };
}
toggle('#tTrump', 'trumpet'); toggle('#tMetro', 'metro'); toggle('#tCount', 'count'); toggle('#tLoop', 'loop');
$('#play').onclick = () => P.playing ? stop() : start();
$('#bpm').oninput = e => setBpm(+e.target.value);
$('#bm').onclick = () => setBpm(S.bpm - 2);
$('#bp').onclick = () => setBpm(S.bpm + 2);

toggle('#tPlay', 'play'); toggle('#tHint', 'hint');
['#tPlay', '#tHint'].forEach(id => { const b = $(id), o = b.onclick; b.onclick = () => { o(); if (!P.playing) { pressed.clear(); drawP(); $('#msg').textContent = S.play && id === '#tPlay' ? 'Toca los pistones al ritmo (1 2 3 o J K L). Cuenta previa y metrónomo incluidos.' : ''; } }; });
// entrada: pistones táctiles y teclado
const pid = new Map(), ks = new Set();
const press = () => { pressed = new Set([...pid.values(), ...ks]); if (S.play) drawP(); };
[[1, 0, 100], [2, 100, 200], [3, 200, 300]].forEach(([n, x0, x1]) => {
  const r = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  r.setAttribute('x', x0); r.setAttribute('y', 30); r.setAttribute('width', x1 - x0); r.setAttribute('height', 215); r.setAttribute('fill', 'transparent');
  r.onpointerdown = e => { r.setPointerCapture(e.pointerId); pid.set(e.pointerId, n); press(); };
  r.onpointerup = r.onpointercancel = e => { pid.delete(e.pointerId); press(); };
  $('.pistons').appendChild(r);
});
const KM = { '1': 1, '2': 2, '3': 3, j: 1, k: 2, l: 3 };
addEventListener('keydown', e => { if (KM[e.key] && !e.repeat) { ks.add(KM[e.key]); press(); } });
addEventListener('keyup', e => { if (KM[e.key]) { ks.delete(KM[e.key]); press(); } });
addEventListener('blur', () => { ks.clear(); pid.clear(); press(); });
fillRoots(); render();

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
