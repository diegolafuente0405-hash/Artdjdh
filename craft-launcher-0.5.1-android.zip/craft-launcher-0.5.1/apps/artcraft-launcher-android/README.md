# ArtCraft Launcher for Android

The Android build of ArtCraft Launcher: the shared egui interface (`crates/ui-egui`) running in a
NativeActivity, drawn with OpenGL ES.

**What it does.** The Craft apps ship for Windows, macOS, Linux and FreeBSD, not for phones, so on
Android the launcher works like the web build: it lists the whole Craft App Suite with each app's
latest release (read from the GitHub API) and opens the release page, where the downloads for your
computer are. It installs nothing on the phone (`manage_apps: false`, `platform() == None`).
Theme, language, grid/table view, search, filters and the app detail pages all work; settings are
saved to the app's private folder.

## Build

Easiest: run the **android** workflow (GitHub Actions → *android* → *Run workflow*); it uploads
`artcraft-launcher-<version>-android.apk`.

Locally (Linux or macOS):

```sh
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
# Android SDK (platform 34, build-tools 34) and NDK (r26 or newer), then:
export ANDROID_HOME=$HOME/Android/Sdk
export ANDROID_NDK_ROOT=$ANDROID_HOME/ndk/<version>
cargo install --locked --git https://github.com/parasyte/cargo-apk.git \
  --rev 282639508eeed7d73f2e1eaeea042da2716436d5 cargo-apk

cd apps/artcraft-launcher-android
# Debug build, signed with the debug key; install on a connected phone:
cargo apk run --lib
# Release build; needs a keystore:
export CARGO_APK_RELEASE_KEYSTORE=/path/to/release.keystore
export CARGO_APK_RELEASE_KEYSTORE_PASSWORD=...
cargo apk build --release --lib      # target/release/apk/*.apk
```

To install the APK from a file, allow "install unknown apps" for your file manager or browser.

## Notes

- This crate is **not** a member of the root workspace (`exclude` in the root `Cargo.toml`): it
  has its own `Cargo.lock` and its own profile, so the desktop and web CI (`--locked`) is
  unaffected. Keep `version` in step with `[workspace.package]`.
- `target_sdk_version = 34` on purpose: from 35 Android forces apps edge to edge under the status
  bar, and NativeActivity gives egui no safe-area insets.
- HTTPS trusts the phone's own root certificates, read from
  `/apex/com.android.conscrypt/cacerts` or `/system/etc/security/cacerts`; no root list is bundled.
- Not supported on Android: tray icon, notifications, start at login, installing or launching
  Craft apps, self-update, and CJK languages (the system CJK font is only looked up on desktop,
  so those fall back to English).
