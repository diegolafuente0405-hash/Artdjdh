//! ArtCraft Launcher for Android.
//!
//! The Craft apps ship builds for desktops, not phones, so an Android launcher can't install
//! them. What it can do is what the browser build does: list the Craft App Suite with each app's
//! latest release (read from the GitHub API) and open the release page, where the download for
//! the person's computer lives. The interface is the shared egui one (`artcraft-launcher-ui-egui`),
//! drawn with OpenGL ES inside a NativeActivity; this crate only supplies the Android backend
//! and the entry point.
//!
//! Build it with `cargo apk build --release` (see README.md in this folder).

#![deny(clippy::unwrap_used, clippy::expect_used, clippy::panic, clippy::unimplemented, clippy::todo, clippy::unreachable)]

#[cfg(target_os = "android")]
mod backend;
mod shell;

/// Where Android calls into the app. `cargo apk` / NativeActivity looks for exactly this symbol.
///
/// The one `unsafe` in the crate is the attribute itself (`no_mangle` is an unsafe attribute in
/// the 2024 edition).
#[cfg(target_os = "android")]
#[unsafe(no_mangle)]
fn android_main(app: winit::platform::android::activity::AndroidApp) {
    android_logger::init_once(android_logger::Config::default().with_tag("ArtCraftLauncher").with_max_level(log::LevelFilter::Info));
    std::panic::set_hook(Box::new(|info| log::error!("panic: {info}")));
    shell::run(app);
}
