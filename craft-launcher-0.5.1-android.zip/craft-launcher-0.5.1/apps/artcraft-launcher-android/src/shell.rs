//! The eframe shell: window options, saved settings, and the glue to [`LauncherUi`].

#[cfg(target_os = "android")]
use std::path::PathBuf;
#[cfg(target_os = "android")]
use std::time::{Duration, Instant};

#[cfg(target_os = "android")]
use artcraft_launcher_ui_egui::{Host, LauncherUi, Settings};

/// What the phone adds to the shared UI: nothing but a name for the platform. No tray, no login
/// item, no folder picker, no window controls (`TitleBar::Native`, the default).
#[cfg(target_os = "android")]
struct AndroidHost;

#[cfg(target_os = "android")]
impl Host for AndroidHost {}

/// Settings live in the app's private folder as JSON (eframe has no storage on Android).
#[cfg(target_os = "android")]
struct Store {
    path: Option<PathBuf>,
    last: String,
    checked: Instant,
}

#[cfg(target_os = "android")]
impl Store {
    const FILE: &'static str = "settings.json";
    const EVERY: Duration = Duration::from_secs(2);

    fn new(app: &winit::platform::android::activity::AndroidApp) -> Self {
        Self { path: app.internal_data_path().map(|dir| dir.join(Self::FILE)), last: String::new(), checked: Instant::now() }
    }

    fn load(&mut self) -> Settings {
        let text = self.path.as_deref().and_then(|p| std::fs::read_to_string(p).ok());
        let settings = text.as_deref().and_then(|t| serde_json::from_str::<Settings>(t).ok()).unwrap_or_default();
        self.last = serde_json::to_string(&settings).unwrap_or_default();
        settings
    }

    /// Writes the settings when they changed; looks at most every couple of seconds.
    fn save_if_changed(&mut self, settings: &Settings) {
        if self.checked.elapsed() < Self::EVERY {
            return;
        }
        self.checked = Instant::now();
        let (Some(path), Ok(json)) = (self.path.as_deref(), serde_json::to_string(settings)) else { return };
        if json == self.last {
            return;
        }
        // Written beside, then renamed: a half-written file never replaces good settings.
        let temp = path.with_extension("json.tmp");
        match std::fs::write(&temp, &json).and_then(|()| std::fs::rename(&temp, path)) {
            Ok(()) => self.last = json,
            Err(e) => log::warn!("couldn't save settings: {e}"),
        }
    }
}

#[cfg(target_os = "android")]
struct App {
    ui: LauncherUi,
    store: Store,
}

#[cfg(target_os = "android")]
impl eframe::App for App {
    fn logic(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        self.ui.logic(ctx, &mut AndroidHost);
        self.store.save_if_changed(&self.ui.settings);
    }

    fn ui(&mut self, ui: &mut egui::Ui, _frame: &mut eframe::Frame) {
        self.ui.ui(ui, &mut AndroidHost);
    }

    fn raw_input_hook(&mut self, ctx: &egui::Context, raw_input: &mut egui::RawInput) {
        self.ui.raw_input(ctx, raw_input);
    }
}

/// Runs the launcher until the activity ends.
#[cfg(target_os = "android")]
pub fn run(app: winit::platform::android::activity::AndroidApp) {
    // The phone's languages, so the "Automatic" interface language follows it.
    artcraft_launcher_ui_egui::i18n::detect_system_lang_in_background();
    let mut store = Store::new(&app);
    let options = eframe::NativeOptions { android_app: Some(app), ..Default::default() };
    let result = eframe::run_native(
        "ArtCraft Launcher",
        options,
        Box::new(move |cc| {
            let settings = store.load();
            let backend = crate::backend::AndroidBackend::new(cc.egui_ctx.clone());
            Ok(Box::new(App { ui: LauncherUi::new(&cc.egui_ctx, Box::new(backend), settings), store }))
        }),
    );
    if let Err(e) = result {
        log::error!("couldn't start: {e}");
    }
}

/// Not Android: this crate only builds a launcher for Android; a desktop build exists so
/// `cargo check` works anywhere.
#[cfg(not(target_os = "android"))]
pub fn run() {
    eprintln!("artcraft-launcher-android is the Android build: run `cargo apk build --release` (see README.md).");
}
