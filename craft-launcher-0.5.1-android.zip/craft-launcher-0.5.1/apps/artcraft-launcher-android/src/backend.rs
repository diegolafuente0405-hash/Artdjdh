//! The Android backend: looks up each Craft app's latest release on GitHub and fetches the
//! pictures of an app's details page. It installs nothing (`manage_apps: false`), so the UI
//! offers each release's page instead.
//!
//! All network work runs on a worker thread and reports through events, like the desktop
//! backend, so a frame never waits on the network.

use std::collections::HashSet;
use std::path::Path;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex, PoisonError};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use artcraft_launcher_core::details::{AppDetails, MAX_SCREENSHOT_BYTES, looks_like_jpeg};
use artcraft_launcher_core::protocol::{Backend, Capabilities, Command, Event, LatestRelease, Origin, Source};
use artcraft_launcher_core::release::{self, Release};
use artcraft_launcher_core::{Platform, SUITE, catalog, version};

const USER_AGENT: &str = concat!("ArtCraft-Launcher/", env!("CARGO_PKG_VERSION"));
/// Largest JSON answer read.
const MAX_JSON: u64 = 4 << 20;
/// Where Android keeps its trusted root certificates: the Conscrypt APEX (Android 14 and later,
/// updated by Google Play system updates), then the classic system folder.
const CERT_DIRS: [&str; 2] = ["/apex/com.android.conscrypt/cacerts", "/system/etc/security/cacerts"];

/// An HTTPS client trusting the phone's own root certificates.
///
/// The files in those folders are PEM (a certificate followed by a text dump of it).
fn agent() -> Result<ureq::Agent, String> {
    let mut certs = Vec::new();
    for dir in CERT_DIRS {
        certs = read_certs(Path::new(dir));
        if !certs.is_empty() {
            break;
        }
    }
    if certs.is_empty() {
        return Err("couldn't read this phone's trusted certificates".into());
    }
    let tls = ureq::tls::TlsConfig::builder().root_certs(ureq::tls::RootCerts::new_with_certs(&certs)).build();
    Ok(ureq::Agent::config_builder()
        .tls_config(tls)
        .timeout_global(Some(Duration::from_secs(20)))
        .http_status_as_error(false)
        .user_agent(USER_AGENT)
        .build()
        .new_agent())
}

fn read_certs(dir: &Path) -> Vec<ureq::tls::Certificate<'static>> {
    let Ok(entries) = std::fs::read_dir(dir) else { return Vec::new() };
    entries
        .filter_map(Result::ok)
        .filter_map(|entry| std::fs::read(entry.path()).ok())
        .filter_map(|pem| ureq::tls::Certificate::from_pem(&pem).ok())
        .collect()
}

fn now() -> i64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map_or(0, |d| i64::try_from(d.as_secs()).unwrap_or(i64::MAX))
}

pub struct AndroidBackend {
    events: Arc<Mutex<Vec<Event>>>,
    ctx: egui::Context,
    checking: Arc<AtomicBool>,
    prereleases: bool,
    /// Apps whose details pictures are on their way (asking again meanwhile does nothing).
    pictures_busy: Arc<Mutex<HashSet<&'static str>>>,
}

impl AndroidBackend {
    pub fn new(ctx: egui::Context) -> Self {
        Self { events: Arc::default(), ctx, checking: Arc::default(), prereleases: false, pictures_busy: Arc::default() }
    }

    fn check(&self) {
        if self.checking.swap(true, Ordering::SeqCst) {
            return;
        }
        let (events, ctx, checking, prereleases) = (self.events.clone(), self.ctx.clone(), self.checking.clone(), self.prereleases);
        let spawned = std::thread::Builder::new().name("check".into()).spawn(move || {
            push(&events, &ctx, Event::CheckStarted);
            let mut limited = None;
            match agent() {
                Ok(agent) => {
                    for app in &SUITE {
                        let latest = latest(&agent, app.repo, prereleases);
                        if let Err(Failure::RateLimited(reset)) = &latest {
                            limited = Some(*reset);
                        }
                        let latest = latest.unwrap_or_else(|f| LatestRelease::Failed(f.why().into()));
                        push(&events, &ctx, Event::Latest { app: app.id.to_string(), latest, from: Origin::GitHub });
                    }
                    if let Ok(LatestRelease::Found(r)) = latest(&agent, catalog::LAUNCHER_REPO, false)
                        && let (Some(l), Some(c)) = (r.version.as_ref(), version::parse(env!("CARGO_PKG_VERSION")))
                        && version::is_newer(l, &c)
                    {
                        push(&events, &ctx, Event::LauncherUpdate(r));
                    }
                }
                Err(why) => {
                    log::warn!("{why}");
                    for app in &SUITE {
                        push(
                            &events,
                            &ctx,
                            Event::Latest { app: app.id.to_string(), latest: LatestRelease::Failed(why.clone()), from: Origin::GitHub },
                        );
                    }
                }
            }
            push(&events, &ctx, Event::CheckFinished { at: now(), source: Source::GitHubApi, rate_limited_until: limited });
            checking.store(false, Ordering::SeqCst);
        });
        if let Err(e) = spawned {
            log::error!("couldn't start the update check: {e}");
            self.checking.store(false, Ordering::SeqCst);
        }
    }

    /// Fetches the pictures of an app's details page, lead first.
    fn fetch_screenshots(&self, app: &str) {
        let Some(details) = AppDetails::by_id(app) else { return };
        if !self.pictures_busy.lock().unwrap_or_else(PoisonError::into_inner).insert(details.id) {
            return;
        }
        let (events, ctx, busy) = (self.events.clone(), self.ctx.clone(), self.pictures_busy.clone());
        let spawned = std::thread::Builder::new().name("pictures".into()).spawn(move || {
            let agent = agent();
            // Once the network has failed the rest would fail the same way: say so at once.
            let mut offline: Option<String> = None;
            for shot in details.shots {
                let result = match (&offline, &agent, details.screenshot_url(shot.key)) {
                    (Some(why), _, _) => Err(why.clone()),
                    (None, Err(why), _) => Err(why.clone()),
                    (None, Ok(agent), Some(url)) => picture(agent, &url).map_err(|failure| match failure {
                        PictureError::Network(why) => {
                            offline = Some(why.clone());
                            why
                        }
                        PictureError::Picture(why) => why,
                    }),
                    (None, Ok(_), None) => Err("this page has no such picture".to_string()),
                };
                push(&events, &ctx, Event::Screenshot { app: details.id.to_string(), key: shot.key.to_string(), result });
            }
            busy.lock().unwrap_or_else(PoisonError::into_inner).remove(details.id);
        });
        if let Err(e) = spawned {
            log::error!("couldn't start the picture download: {e}");
            self.pictures_busy.lock().unwrap_or_else(PoisonError::into_inner).remove(details.id);
        }
    }
}

fn push(events: &Mutex<Vec<Event>>, ctx: &egui::Context, event: Event) {
    events.lock().unwrap_or_else(PoisonError::into_inner).push(event);
    ctx.request_repaint();
}

/// Why a release lookup failed.
enum Failure {
    /// GitHub refused more API calls until this time (Unix seconds; 0 when it didn't say).
    RateLimited(i64),
    Other,
}

impl Failure {
    fn why(&self) -> &'static str {
        match self {
            Self::RateLimited(_) => "GitHub's hourly limit was reached",
            Self::Other => "couldn't reach GitHub",
        }
    }
}

/// The latest release of `repo` (or the newest of the last 30, counting pre-releases).
fn latest(agent: &ureq::Agent, repo: &str, prereleases: bool) -> Result<LatestRelease, Failure> {
    let url = if prereleases {
        format!("https://api.github.com/repos/{repo}/releases?per_page=30")
    } else {
        format!("https://api.github.com/repos/{repo}/releases/latest")
    };
    let mut resp =
        agent.get(&url).header("Accept", "application/vnd.github+json").header("X-GitHub-Api-Version", "2022-11-28").call().map_err(|e| {
            log::warn!("{repo}: {e}");
            Failure::Other
        })?;
    match resp.status().as_u16() {
        200 => {}
        404 => return Ok(LatestRelease::None),
        403 | 429 => {
            let reset = resp.headers().get("x-ratelimit-reset").and_then(|v| v.to_str().ok()).and_then(|v| v.trim().parse::<i64>().ok());
            return Err(Failure::RateLimited(reset.unwrap_or(0)));
        }
        status => {
            log::warn!("{repo}: GitHub answered HTTP {status}");
            return Err(Failure::Other);
        }
    }
    let text = resp.body_mut().with_config().limit(MAX_JSON).read_to_string().map_err(|e| {
        log::warn!("{repo}: unreadable answer ({e})");
        Failure::Other
    })?;
    let found: Option<Release> = if prereleases {
        release::parse_github_release_list(&text, repo, true).map_err(|e| {
            log::warn!("{repo}: {e}");
            Failure::Other
        })?
    } else {
        Some(release::parse_github_release(&text, repo).map_err(|e| {
            log::warn!("{repo}: {e}");
            Failure::Other
        })?)
    };
    Ok(found.map_or(LatestRelease::None, LatestRelease::Found))
}

/// Why a picture couldn't be had.
enum PictureError {
    /// This picture only: it isn't published, or what came back isn't a picture.
    Picture(String),
    /// The network or the server: the other pictures would fail the same way.
    Network(String),
}

/// One picture of a details page. The size cap is checked on the announced length first and again
/// on what arrived; the bytes must start like a JPEG.
fn picture(agent: &ureq::Agent, url: &str) -> Result<Vec<u8>, PictureError> {
    let offline = |what: &str| PictureError::Network(format!("couldn't load a picture ({what})"));
    let mut resp = agent.get(url).call().map_err(|_| offline("no connection"))?;
    match resp.status().as_u16() {
        200 => {}
        404 => return Err(PictureError::Picture("this picture isn't published".into())),
        status => return Err(PictureError::Network(format!("the server answered HTTP {status}"))),
    }
    let too_big = || PictureError::Picture(format!("a picture of more than {MAX_SCREENSHOT_BYTES} bytes"));
    let announced = resp.headers().get("content-length").and_then(|v| v.to_str().ok()).and_then(|v| v.parse::<usize>().ok());
    if announced.is_some_and(|n| n > MAX_SCREENSHOT_BYTES) {
        return Err(too_big());
    }
    // ureq errors once the limit is reached, so ask for one byte more than is accepted.
    let bytes = resp.body_mut().with_config().limit(MAX_SCREENSHOT_BYTES as u64 + 1).read_to_vec().map_err(|_| offline("unreadable"))?;
    if bytes.len() > MAX_SCREENSHOT_BYTES {
        return Err(too_big());
    }
    if !looks_like_jpeg(&bytes) {
        return Err(PictureError::Picture("the answer isn't a JPEG picture".into()));
    }
    Ok(bytes)
}

impl Backend for AndroidBackend {
    fn send(&mut self, command: Command) {
        match command {
            Command::CheckForUpdates { .. } => self.check(),
            Command::FetchScreenshots { app } => self.fetch_screenshots(&app),
            Command::Configure(options) => {
                let changed = options.prereleases != self.prereleases;
                self.prereleases = options.prereleases;
                if changed {
                    self.check();
                }
            }
            // Nothing is installed here: the rest is for backends that manage apps.
            _ => {}
        }
    }

    fn poll(&mut self) -> Vec<Event> {
        std::mem::take(&mut *self.events.lock().unwrap_or_else(PoisonError::into_inner))
    }

    fn capabilities(&self) -> Capabilities {
        Capabilities { manage_apps: false, reveal_label: "", self_update: false }
    }

    /// There are no Craft builds for Android, so no platform: every app offers its release page.
    fn platform(&self) -> Option<Platform> {
        None
    }

    fn now(&self) -> i64 {
        now()
    }
}
