//! Starting programs: the Craft Apps themselves, the file manager, and helper tools.

use std::path::Path;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::{Duration, Instant};

/// A `Command` that won't flash a console window on Windows, and clears AppImage-injected
/// environment variables that corrupt system helper binaries and external applications.
pub fn command(program: impl AsRef<std::ffi::OsStr>) -> Command {
    #[allow(unused_mut)]
    let mut cmd = Command::new(program);
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        cmd.creation_flags(CREATE_NO_WINDOW);
    }
    #[cfg(unix)]
    clean_appimage_env(&mut cmd);
    cmd
}

/// Cleans AppImage runtime environment variables so child processes don't load incompatible
/// libraries from the launcher's bundled AppImage.
#[cfg(unix)]
pub fn clean_appimage_env(cmd: &mut Command) {
    if std::env::var_os("APPIMAGE").is_some() {
        for var in [
            "LD_LIBRARY_PATH",
            "LD_PRELOAD",
            "APPDIR",
            "APPIMAGE",
            "ARGV0",
            "OWD",
            "GDK_PIXBUF_MODULE_FILE",
            "GIO_MODULE_DIR",
            "GTK_PATH",
            "PYTHONHOME",
            "QT_PLUGIN_PATH",
        ] {
            cmd.env_remove(var);
        }
    }
}

/// Runs a helper and returns its standard output when it succeeds within `timeout`.
pub fn capture(program: &str, args: &[&str], timeout: Duration) -> Option<String> {
    run(program, args, timeout).ok()
}

/// Runs a helper and returns its standard output when it succeeds within `timeout`; otherwise
/// the reason, in the helper's own words (its standard error) where it gave one.
pub fn run(program: &str, args: &[&str], timeout: Duration) -> Result<String, String> {
    let mut cmd = command(program);
    cmd.args(args);
    run_command(cmd, program, timeout)
}

/// Runs a configured helper with bounded output and a timeout.
pub fn run_command(mut cmd: Command, program: &str, timeout: Duration) -> Result<String, String> {
    let mut child =
        cmd.stdin(Stdio::null()).stdout(Stdio::piped()).stderr(Stdio::piped()).spawn().map_err(|e| format!("couldn't start {program} ({e})"))?;
    // Read both pipes while it runs, so a chatty helper can't block on a full one.
    let (stdout, stderr) = (read_all(child.stdout.take()), read_all(child.stderr.take()));
    let start = Instant::now();
    let status = loop {
        match child.try_wait() {
            Ok(Some(status)) => break status,
            Ok(None) if start.elapsed() < timeout => std::thread::sleep(Duration::from_millis(15)),
            _ => {
                let _ = child.kill();
                let _ = child.wait();
                return Err(format!("{program} didn't finish within {} seconds", timeout.as_secs()));
            }
        }
    };
    let text = |pipe: std::thread::JoinHandle<Vec<u8>>| String::from_utf8_lossy(&pipe.join().unwrap_or_default()).into_owned();
    let (out, err) = (text(stdout), text(stderr));
    if status.success() {
        return Ok(out);
    }
    let reason = err.trim();
    Err(if reason.is_empty() { format!("{program} failed ({status})") } else { reason.to_string() })
}

/// Reads a child's pipe to the end (at most 8 MB) on its own thread.
fn read_all<R: std::io::Read + Send + 'static>(pipe: Option<R>) -> std::thread::JoinHandle<Vec<u8>> {
    std::thread::spawn(move || {
        let mut out = Vec::new();
        if let Some(pipe) = pipe {
            let _ = std::io::Read::read_to_end(&mut std::io::Read::take(pipe, 8 << 20), &mut out);
        }
        out
    })
}

/// Starts `cmd` without waiting for it, and reaps it when it exits.
pub fn spawn_detached(mut cmd: Command) -> Result<(), String> {
    let mut child = cmd.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn().map_err(|e| format!("couldn't start it ({e})"))?;
    std::thread::spawn(move || {
        let _ = child.wait();
    });
    Ok(())
}

/// Whether this process is running inside a Flatpak container sandbox.
pub fn in_sandbox() -> bool {
    std::env::var_os("FLATPAK_ID").is_some() || Path::new("/.flatpak-info").exists()
}

/// A command to run `flatpak`, delegating to the host via `flatpak-spawn --host` if inside a sandbox.
pub fn flatpak_command() -> Command {
    if in_sandbox() {
        let mut cmd = command("flatpak-spawn");
        cmd.args(["--host", "flatpak"]);
        cmd
    } else {
        command("flatpak")
    }
}

/// Runs a flatpak command and captures its standard output.
pub fn capture_flatpak(args: &[&str], timeout: Duration) -> Option<String> {
    if in_sandbox() {
        let mut spawn_args = vec!["--host", "flatpak"];
        spawn_args.extend_from_slice(args);
        capture("flatpak-spawn", &spawn_args, timeout)
    } else {
        capture("flatpak", args, timeout)
    }
}

/// Whether Flatpak is available on the machine (or on the host when sandboxed).
pub fn is_flatpak_available() -> bool {
    if in_sandbox() {
        capture("flatpak-spawn", &["--host", "flatpak", "--version"], Duration::from_secs(3)).is_some()
    } else {
        which_on_path("flatpak").is_some()
    }
}

static DISCORD_HANDLER_DETECTED: AtomicBool = AtomicBool::new(false);
static DETECTION_STARTED: AtomicBool = AtomicBool::new(false);

/// Starts asynchronous detection of a registered Discord URL scheme handler in the background.
pub fn ensure_discord_detection_started() {
    if !DETECTION_STARTED.swap(true, Ordering::Relaxed) {
        let _ = std::thread::Builder::new().name("discord-detect".into()).spawn(|| {
            let detected = detect_discord_scheme_handler();
            DISCORD_HANDLER_DETECTED.store(detected, Ordering::Relaxed);
        });
    }
}

/// Whether a registered Discord scheme handler has been detected on this machine.
///
/// Triggers background detection if not yet started, and returns immediately without
/// blocking the calling thread.
pub fn is_discord_installed() -> bool {
    ensure_discord_detection_started();
    DISCORD_HANDLER_DETECTED.load(Ordering::Relaxed)
}

/// The URL to use for Discord links: deep-links to the app if a handler is registered,
/// else the web invite. Non-blocking (detection runs in the background).
pub fn discord_url() -> &'static str {
    if is_discord_installed() { artcraft_launcher_core::catalog::DISCORD_APP_URL } else { artcraft_launcher_core::catalog::DISCORD_URL }
}

#[cfg(windows)]
fn detect_discord_scheme_handler() -> bool {
    use winreg::RegKey;
    use winreg::enums::{HKEY_CLASSES_ROOT, HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE, KEY_READ};

    for hive in [HKEY_CURRENT_USER, HKEY_CLASSES_ROOT, HKEY_LOCAL_MACHINE] {
        let subkey = if hive == HKEY_CLASSES_ROOT { r"discord\shell\open\command" } else { r"Software\Classes\discord\shell\open\command" };
        if let Ok(key) = RegKey::predef(hive).open_subkey_with_flags(subkey, KEY_READ)
            && let Ok(val) = key.get_value::<String, _>("")
            && !val.trim().is_empty()
        {
            return true;
        }
    }
    false
}

#[cfg(target_os = "macos")]
fn detect_discord_scheme_handler() -> bool {
    macos_discord_candidates(dirs::home_dir().as_deref()).iter().any(|app_dir| {
        let plist_path = app_dir.join("Contents/Info.plist");
        if let Ok(content) = std::fs::read_to_string(&plist_path) { content.contains("<string>discord</string>") } else { false }
    })
}

#[cfg(any(target_os = "macos", test))]
fn macos_discord_candidates(home: Option<&Path>) -> Vec<std::path::PathBuf> {
    let apps = ["Discord.app", "Discord Canary.app", "Discord PTB.app", "Discord Development.app"];
    let mut dirs = vec![std::path::PathBuf::from("/Applications")];
    if let Some(home) = home {
        dirs.push(home.join("Applications"));
    }
    let mut out = Vec::new();
    for dir in dirs {
        for app in apps {
            out.push(dir.join(app));
        }
    }
    out
}

#[cfg(target_os = "linux")]
fn detect_discord_scheme_handler() -> bool {
    // 1. Query xdg-mime for the registered scheme handler (on host or in flatpak sandbox).
    let mime_query = if in_sandbox() {
        capture("flatpak-spawn", &["--host", "xdg-mime", "query", "default", "x-scheme-handler/discord"], Duration::from_millis(800))
    } else {
        capture("xdg-mime", &["query", "default", "x-scheme-handler/discord"], Duration::from_millis(800))
    };
    if let Some(out) = mime_query {
        let trimmed = out.trim();
        if !trimmed.is_empty() && trimmed.ends_with(".desktop") {
            return true;
        }
    }

    // 2. Fall back to inspecting installed desktop files to ensure MimeType includes
    // x-scheme-handler/discord (preventing silent failures as in Arch FS#76847).
    for path in linux_discord_candidates(dirs::home_dir().as_deref()) {
        if path.extension().is_some_and(|ext| ext == "desktop")
            && let Ok(content) = std::fs::read_to_string(&path)
            && content.lines().any(|line| {
                let line = line.trim();
                line.starts_with("MimeType=") && line.contains("x-scheme-handler/discord")
            })
        {
            return true;
        }
    }

    false
}

#[cfg(any(target_os = "linux", test))]
fn linux_discord_candidates(home: Option<&Path>) -> Vec<std::path::PathBuf> {
    let mut files = vec![
        std::path::PathBuf::from("/usr/share/applications/discord.desktop"),
        std::path::PathBuf::from("/usr/share/applications/discord-canary.desktop"),
        std::path::PathBuf::from("/usr/share/applications/discord-ptb.desktop"),
        std::path::PathBuf::from("/var/lib/flatpak/exports/share/applications/com.discordapp.Discord.desktop"),
        std::path::PathBuf::from("/var/lib/flatpak/exports/share/applications/com.discordapp.DiscordCanary.desktop"),
        std::path::PathBuf::from("/var/lib/snapd/desktop/applications/discord_discord.desktop"),
        std::path::PathBuf::from("/snap/bin/discord"),
    ];
    if let Some(home) = home {
        files.push(home.join(".local/share/applications/discord.desktop"));
        files.push(home.join(".local/share/applications/discord-canary.desktop"));
        files.push(home.join(".local/share/applications/discord-ptb.desktop"));
        files.push(home.join(".local/share/flatpak/exports/share/applications/com.discordapp.Discord.desktop"));
        files.push(home.join(".local/share/flatpak/exports/share/applications/com.discordapp.DiscordCanary.desktop"));
    }
    files
}

#[cfg(not(any(windows, target_os = "macos", target_os = "linux")))]
fn detect_discord_scheme_handler() -> bool {
    false
}

fn which_on_path(name: &str) -> Option<std::path::PathBuf> {
    let path = std::env::var_os("PATH")?;
    std::env::split_paths(&path).map(|d| d.join(name)).find(|p| p.is_file())
}

/// Starts an app binary from its own folder.
pub fn launch_binary(exe: &Path, args: &[&str]) -> Result<(), String> {
    let mut cmd = if in_sandbox() {
        let mut c = command("flatpak-spawn");
        c.arg("--host").arg(exe);
        c
    } else {
        command(exe)
    };
    cmd.args(args);
    if let Some(dir) = exe.parent() {
        cmd.current_dir(dir);
    }
    spawn_detached(cmd)
}

/// Opens a file, folder or URL with the system's default handler.
pub fn open(target: &std::ffi::OsStr) -> Result<(), String> {
    spawn_detached(opener(target))
}

/// The system's default opener for `target`: `explorer` on Windows, `open` on macOS, and
/// `xdg-open` elsewhere (on the host, through `flatpak-spawn --host`, inside the sandbox).
fn opener(target: &std::ffi::OsStr) -> Command {
    let mut cmd = if cfg!(target_os = "macos") {
        command("open")
    } else if cfg!(windows) {
        command("explorer")
    } else if in_sandbox() {
        let mut c = command("flatpak-spawn");
        c.arg("--host").arg("xdg-open");
        c
    } else {
        command("xdg-open")
    };
    cmd.arg(target);
    cmd
}

/// Opens `primary_url` with the system's default handler. If opening fails (for example,
/// if a custom scheme handler is not found or fails to execute), falls back to `fallback_url`.
pub fn open_url_with_fallback(primary_url: &str, fallback_url: &str) {
    let primary = primary_url.to_string();
    let fallback = fallback_url.to_string();
    std::thread::spawn(move || {
        if !open_and_wait_success(&primary, Duration::from_millis(1500)) {
            log::warn!("couldn't open {primary}; falling back to {fallback}");
            let _ = open(std::ffi::OsStr::new(&fallback));
        }
    });
}

/// Starts the default system opener for `target` and returns `true` unless it fails to start
/// or exits in error within `timeout`. An opener still running after `timeout` counts as
/// success and is reaped in the background.
///
/// `explorer` exits with an error status even when it opens the target, so on Windows only a
/// failure to start counts; the registry check in `detect_discord_scheme_handler` covers the rest.
fn open_and_wait_success(target: &str, timeout: Duration) -> bool {
    let mut cmd = opener(std::ffi::OsStr::new(target));
    if cfg!(windows) {
        return spawn_detached(cmd).is_ok();
    }
    let mut child = match cmd.stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn() {
        Ok(c) => c,
        Err(e) => {
            log::warn!("couldn't start the opener for {target}: {e}");
            return false;
        }
    };
    let start = Instant::now();
    loop {
        match child.try_wait() {
            Ok(Some(status)) => return status.success(),
            Ok(None) if start.elapsed() < timeout => std::thread::sleep(Duration::from_millis(25)),
            Ok(None) => {
                std::thread::spawn(move || {
                    let _ = child.wait();
                });
                return true;
            }
            Err(_) => return false,
        }
    }
}

/// Shows `path` selected in the file manager.
pub fn reveal(path: &Path) -> Result<(), String> {
    if cfg!(target_os = "macos") {
        let mut cmd = command("open");
        cmd.arg("-R").arg(path);
        spawn_detached(cmd)
    } else if cfg!(windows) {
        reveal_in_explorer(path)
    } else {
        open(path.parent().unwrap_or(path).as_os_str())
    }
}

#[cfg(windows)]
fn reveal_in_explorer(path: &Path) -> Result<(), String> {
    use std::os::windows::process::CommandExt;
    let mut cmd = command("explorer");
    // Passed raw: `arg` would wrap all of `/select,...` in quotes when the path has a space
    // (`C:\Program Files\...`), and Explorer then ignores the switch and opens Documents.
    // A quote in the path would end the quoted part early and let the rest reach Explorer as
    // switches; no Windows path has one, so refuse it.
    let arg = explorer_select_arg(path).ok_or_else(|| format!("{} isn't a usable path", path.display()))?;
    cmd.raw_arg(arg);
    spawn_detached(cmd)
}

#[cfg(not(windows))]
fn reveal_in_explorer(_path: &Path) -> Result<(), String> {
    Err("Explorer is only on Windows".into())
}

/// Explorer's `/select,"<path>"` argument as it goes on the command line: only the path is quoted,
/// and forward slashes become backslashes, which Explorer needs to find the item. `None` for a path
/// with a `"` in it.
#[cfg_attr(not(windows), allow(dead_code))]
fn explorer_select_arg(path: &Path) -> Option<std::ffi::OsString> {
    let s = path.to_str()?;
    if s.contains('"') {
        return None;
    }
    let mut arg = std::ffi::OsString::from("/select,\"");
    arg.push(s.replace('/', "\\"));
    arg.push("\"");
    Some(arg)
}

/// Whether a process started from inside `path` (an exe, an AppImage, or a `.app`) is running.
pub fn is_running(path: &Path) -> bool {
    if cfg!(windows) {
        let Some(name) = path.file_name().and_then(|n| n.to_str()) else { return false };
        let filter = format!("IMAGENAME eq {name}");
        capture("tasklist", &["/FI", &filter, "/NH", "/FO", "CSV"], Duration::from_secs(5))
            .is_some_and(|out| out.to_ascii_lowercase().contains(&name.to_ascii_lowercase()))
    } else {
        let Some(p) = path.to_str() else { return false };
        let pattern = pgrep_pattern(p);
        // pgrep exits 0 when something matches; it never matches itself.
        if in_sandbox() {
            capture("flatpak-spawn", &["--host", "pgrep", "-f", "--", &pattern], Duration::from_secs(5)).is_some()
        } else {
            capture("pgrep", &["-f", "--", &pattern], Duration::from_secs(5)).is_some()
        }
    }
}

/// Quote the path's metacharacters for pgrep's extended regular expression.
fn pgrep_pattern(path: &str) -> String {
    let mut pattern = String::with_capacity(path.len());
    for c in path.chars() {
        if matches!(c, '.' | '^' | '$' | '*' | '+' | '?' | '(' | ')' | '[' | ']' | '{' | '}' | '|' | '\\') {
            pattern.push('\\');
        }
        pattern.push(c);
    }
    pattern
}

#[cfg(test)]
#[cfg(unix)]
mod tests {
    use std::io::{BufRead, BufReader};
    use std::process::Child;

    use super::*;

    struct RunningProbe(Child);

    impl RunningProbe {
        fn start(path: &str) -> Self {
            let child = command("/bin/sh")
                .args(["-c", "printf 'ready\\n'; read line", path])
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::null())
                .spawn()
                .unwrap();
            let mut probe = Self(child);
            let mut ready = String::new();
            BufReader::new(probe.0.stdout.take().unwrap()).read_line(&mut ready).unwrap();
            assert_eq!(ready, "ready\n");
            probe
        }
    }

    impl Drop for RunningProbe {
        fn drop(&mut self) {
            let _ = self.0.kill();
            let _ = self.0.wait();
        }
    }

    #[test]
    fn running_paths_are_matched_literally() {
        let root = format!("/tmp/artcraft-launcher-process-{}", std::process::id());
        for (actual, requested, expected) in [
            ("plain/PhotoCraft.app", "plain/PhotoCraft.app", true),
            ("Apps (work)/PhotoCraft.app", "Apps (work)/PhotoCraft.app", true),
            ("Apps [work]/PhotoCraft.app", "Apps [work]/PhotoCraft.app", true),
            ("other/PhotoCraftXapp", "other/PhotoCraft.app", false),
            ("symbols/应用.^$*+?()[]{}|\\.app", "symbols/应用.^$*+?()[]{}|\\.app", true),
        ] {
            let actual = format!("{root}/{actual}");
            let requested = format!("{root}/{requested}");
            let _probe = RunningProbe::start(&actual);
            assert_eq!(is_running(Path::new(&requested)), expected, "{requested}");
        }
    }
}

#[cfg(test)]
mod run_tests {
    use super::*;

    /// A shell command line, for the platform's shell.
    fn shell(script: &str) -> (&'static str, [&str; 2]) {
        if cfg!(windows) { ("cmd", ["/C", script]) } else { ("/bin/sh", ["-c", script]) }
    }

    #[test]
    fn a_failing_helper_reports_its_own_error() {
        let (program, args) = shell(if cfg!(windows) { "echo no such image 1>&2 & exit /b 3" } else { "echo no such image >&2; exit 3" });
        assert_eq!(run(program, &args, Duration::from_secs(30)), Err("no such image".into()));
        assert_eq!(capture(program, &args, Duration::from_secs(30)), None);
    }

    #[test]
    fn a_silent_failure_and_a_success() {
        let (program, args) = shell("exit 4");
        let err = run(program, &args, Duration::from_secs(30)).unwrap_err();
        assert!(err.starts_with(&format!("{program} failed")), "{err}");
        let (program, args) = shell("echo hello");
        assert_eq!(run(program, &args, Duration::from_secs(30)).map(|out| out.trim().to_string()), Ok("hello".into()));
    }
}

#[cfg(test)]
mod explorer_tests {
    use super::*;

    #[test]
    fn explorer_select_quotes_only_the_path() {
        let arg = explorer_select_arg(Path::new(r"C:\Program Files\PhotoCraft\photocraft.exe"));
        assert_eq!(arg.unwrap(), r#"/select,"C:\Program Files\PhotoCraft\photocraft.exe""#);
    }

    #[test]
    fn explorer_select_without_spaces() {
        let arg = explorer_select_arg(Path::new(r"C:\Apps\photocraft.exe"));
        assert_eq!(arg.unwrap(), r#"/select,"C:\Apps\photocraft.exe""#);
        assert_eq!(explorer_select_arg(Path::new(r#"C:\Apps" /root,C:\x.exe"#)), None);
    }

    #[test]
    fn explorer_select_uses_backslashes() {
        let arg = explorer_select_arg(Path::new("C:/Users/A B/AppData/Local/ArtCraft Launcher/apps/photocraft.exe"));
        assert_eq!(arg.unwrap(), r#"/select,"C:\Users\A B\AppData\Local\ArtCraft Launcher\apps\photocraft.exe""#);
    }
}

#[cfg(test)]
mod discord_tests {
    use super::*;

    #[test]
    fn linux_candidates_include_flatpak_and_system_paths() {
        let fake_home = Path::new("/home/testuser");
        let candidates = linux_discord_candidates(Some(fake_home));
        assert!(candidates.iter().any(|p| p.ends_with("com.discordapp.Discord.desktop")));
        assert!(candidates.iter().any(|p| p == Path::new("/home/testuser/.local/share/applications/discord.desktop")));
        assert!(candidates.iter().any(|p| p == Path::new("/usr/share/applications/discord.desktop")));
        assert!(candidates.iter().any(|p| p == Path::new("/snap/bin/discord")));
    }

    #[test]
    fn macos_candidates_include_standard_apps() {
        let fake_home = Path::new("/Users/testuser");
        let candidates = macos_discord_candidates(Some(fake_home));
        assert!(candidates.iter().any(|p| p == Path::new("/Applications/Discord.app")));
        assert!(candidates.iter().any(|p| p == Path::new("/Users/testuser/Applications/Discord.app")));
        assert!(candidates.iter().any(|p| p == Path::new("/Applications/Discord Canary.app")));
    }

    #[test]
    fn discord_url_gives_app_or_web_url() {
        use artcraft_launcher_core::catalog::{DISCORD_APP_URL, DISCORD_URL};
        let url = discord_url();
        assert!(url == DISCORD_URL || url == DISCORD_APP_URL);
    }
}
