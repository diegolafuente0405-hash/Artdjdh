#include "Renderer.hpp"
#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>

using namespace geode::prelude;
using gpur::Renderer;

// ---------------------------------------------------------------------------
// Un nodo por ZLayer, hijo de m_objectLayer. Así el orden de dibujo respecto al
// jugador y a los demás elementos se mantiene. El primero que se dibuja cada
// frame dispara el compute shader; todos dibujan sus runs.
// ---------------------------------------------------------------------------
class GpuLayerNode : public CCNode {
    int m_zLayer = 0;

public:
    static GpuLayerNode* create(int zLayer) {
        auto* ret = new GpuLayerNode();
        if (ret && ret->init()) {
            ret->m_zLayer = zLayer;
            ret->autorelease();
            return ret;
        }
        CC_SAFE_DELETE(ret);
        return nullptr;
    }

    void draw() override {
        auto& r = Renderer::get();
        if (!r.active()) return;

        // en este punto cocos ya aplicó la transformación de la capa de objetos
        kmMat4 proj, mv, mvp;
        kmGLGetMatrix(KM_GL_PROJECTION, &proj);
        kmGLGetMatrix(KM_GL_MODELVIEW, &mv);
        kmMat4Multiply(&mvp, &proj, &mv);

        r.beginFrameOnce(mvp);
        r.drawLayer(m_zLayer, mvp);
    }
};

// usado por Renderer.cpp
CCNode* gpurMakeLayerNode(int zLayer) { return GpuLayerNode::create(zLayer); }

// ---------------------------------------------------------------------------
// Hooks
// VERIFY (Android): las tres funciones enganchadas abajo (PlayLayer::setupHasCompleted,
// PlayLayer::onQuit y PlayLayer::updateVisibility) deben poder engancharse en Android con los
// bindings de Geode. Si alguna falta, el compilador de Android lo dirá al compilar ese hook
// (no hace falta cambiar nada más).
// ---------------------------------------------------------------------------
class $modify(GpuPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();
        if (Mod::get()->getSettingValue<bool>("enabled")) Renderer::get().onLevelLoaded(this);
    }

    void onQuit() {
        Renderer::get().onLevelUnloaded();
        PlayLayer::onQuit();
    }

    // Con el renderer activo se omiten los visibility checks de GD (la parte más lenta):
    // la GPU hace el culling. VERIFY: confirmar que esta función no hace nada más necesario
    // para el gameplay (activación de objetos, etc.).
    // GD 2.2091: GJBaseGameLayer::updateVisibility quedó como "= inline" en los bindings y ya no
    // se puede enganchar (el compilador lo rechaza). La versión virtual real está en
    // PlayLayer::updateVisibility(float), que sí tiene dirección; por eso el hook vive aquí.
    // El renderer solo se activa desde PlayLayer, así que el comportamiento no cambia.
    void updateVisibility(float dt) {
        if (Renderer::get().active()) return;
        PlayLayer::updateVisibility(dt);
    }
};
