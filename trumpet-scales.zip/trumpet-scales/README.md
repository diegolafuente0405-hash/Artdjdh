# Escalas de Trompeta

App para practicar escalas y arpegios de trompeta en Si♭: pentagrama en clave de Sol, pistones animados con la digitación de cada nota, sonido de trompeta real y metrónomo.

## Estructura

```
index.html            pantalla
styles.css            estilos (azul noche y latón)
src/theory.js         teoría: escalas, armaduras, digitaciones, duraciones (sin DOM, con pruebas)
src/staff.js          dibujo del pentagrama en SVG
src/audio.js          samples de trompeta + metrónomo (Web Audio)
src/app.js            controles y reproductor
src/state.js          ajustes
samples/m<MIDI>.mp3   35 notas (altura real); faltan 54 y 66, se generan desde las vecinas
sw.js, manifest       instalable y funciona sin internet
tests/                npm test
.github/workflows/    compila el APK en la nube
```

Las notas del pentagrama son las **escritas** (trompeta en Si♭). El sonido real es una segunda mayor más grave, y los samples se nombran por el sonido real.

## Probar

Necesita un servidor (los módulos y los samples no cargan con `file://`):

```
npm test          # pruebas de teoría
npm run serve     # http://localhost:8080
```

## Instalar en el celular (PWA)

Publica la carpeta en GitHub Pages (Settings > Pages > Deploy from branch > main). Abre la URL en Chrome del celular y elige "Instalar app" o "Agregar a pantalla de inicio". Después funciona sin internet.

## APK sin PC

1. Sube el proyecto a un repositorio de GitHub.
2. Pestaña **Actions** > **Compilar APK** > **Run workflow**.
3. Cuando termine (unos 5 a 8 minutos), baja `escalas-trompeta-apk` de la sección *Artifacts*, descomprime e instala `app-debug.apk` en el celular.

El APK es de depuración, sirve para uso propio. Para Google Play hace falta firmarlo (se agrega después).

## Cambiar los sonidos por tu Yamaha 3335

Graba cada nota sostenida unos 2 a 3 segundos, sin vibrato. Recórtala, iguala el volumen y guárdala como `samples/m<MIDI sonoro>.mp3` (Do4 sonoro = `m60`). Si cambias archivos, sube `VERSION` en `sw.js`.

## Pendiente

- Modo Cromático (nota suelta, pistones táctiles)
- Lectura a primera vista
- Canciones en MusicXML
- Micrófono para evaluar lo que tocas
