// Dibujo del pentagrama en SVG (clave de Sol), sin librerías externas.
import { SHARP_ORDER, SHARP_STEPS, FLAT_STEPS } from './theory.js';

export const K = 1.25;                   // píxeles por unidad del dibujo
export const Y = (step) => (38 - step) * 5; // y de cada posición (línea superior = 0)
const INK = '#c4cfe6';

function glyph(kind, x, y) {
  const t = `transform="translate(${x} ${y})"`;
  if (kind === 1) return `<g ${t} stroke="currentColor" fill="none" stroke-linecap="round"><path d="M-2.4 -9.5V8.5M2.4 -10.5V7.5" stroke-width="1.3"/><path d="M-5.2 -2.6L5.2 -5M-5.2 4.6L5.2 2.2" stroke-width="2.6"/></g>`;
  if (kind === -1 || kind === -2) {
    const f = `<path d="M0 -13V4.5M0 4.5C7 1 8 -7 0 -3.2" stroke-width="1.6"/>`;
    return kind === -1
      ? `<g stroke="currentColor" fill="none" stroke-linecap="round" transform="translate(${x - 2} ${y - 1})">${f}</g>`
      : `<g stroke="currentColor" fill="none" stroke-linecap="round"><g transform="translate(${x - 6} ${y - 1})">${f}</g><g transform="translate(${x + 2} ${y - 1})">${f}</g></g>`;
  }
  if (kind === 0) return `<g ${t} stroke="currentColor" fill="none" stroke-linecap="round"><path d="M-3 -9V3.6M3 -3.6V9" stroke-width="1.4"/><path d="M-3 -1.8L3 -3.6M-3 3.6L3 1.8" stroke-width="2.2"/></g>`;
  if (kind === 2) return `<g ${t} stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M-4 -4L4 4M-4 4L4 -4"/></g>`;
  return '';
}

const CLEF = `<path d="M17.5 47 C17.5 36 14 22 13.6 6 C13.2 -4 15 -13 19.4 -12 C23 -10.6 21.5 -1 15.5 6 C8 15 2.5 22 3.6 31 C4.5 38 12 40 17 36.5 C22.5 32.5 21.5 24 15.2 22.4 C9.8 21.2 6.8 27.4 10.8 30.6 C13.6 32.8 17 30.4 15.6 27.6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M17.5 47 C17.2 53 11 55.6 8.2 52.2 C6.2 49.6 8.6 46.2 11.6 47.6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/><circle cx="10.6" cy="49.4" r="2.5" fill="currentColor"/>`;

// Dibuja la partitura en #sheet y la clave/armadura/compás en #clefbox.
export function renderStaff(notes, L, root = document) {
  let lo = Infinity, hi = -Infinity;
  notes.forEach(n => { lo = Math.min(lo, n.step); hi = Math.max(hi, n.step); });
  const yMin = Math.min(-22, Y(hi) - 48), yMax = Math.max(66, Y(lo) + 48), H = yMax - yMin;
  const it = L.items.map(a => ({ ...a, y: Y(a.step) }));

  let p = '';
  for (let i = 0; i < 5; i++) p += `<line class="sline" x1="0" x2="${L.endX + 8}" y1="${i * 10}" y2="${i * 10}"/>`;
  L.bars.forEach(x => p += `<line class="sline" x1="${x}" x2="${x}" y1="0" y2="40" stroke-width="1.4"/>`);
  p += `<line class="sline" x1="${L.endX}" x2="${L.endX}" y1="0" y2="40" stroke-width="1.4"/><line class="sline" x1="${L.endX + 5}" x2="${L.endX + 5}" y1="0" y2="40" stroke-width="4"/>`;

  // corcheas unidas de dos en dos, al pulso
  const pairOf = {};
  for (let i = 0; i < it.length - 1; i++) {
    const a = it[i], b = it[i + 1];
    if (a.d === 0.5 && b.d === 0.5 && Math.abs(a.start % 1) < 1e-9 && !pairOf[i]) {
      pairOf[i] = { with: i + 1, lead: true };
      pairOf[i + 1] = { with: i, lead: false };
    }
  }
  const down = {};
  it.forEach((a, i) => {
    down[i] = pairOf[i] ? (a.step + it[pairOf[i].with].step) / 2 >= 34 : a.step >= 34;
  });

  let beams = '';
  it.forEach((a, i) => {
    let g = `<g class="note" id="n${i}">`;
    if (a.step <= 28) for (let s = 28; s >= a.step; s -= 2) g += `<line x1="${a.cx - 10}" x2="${a.cx + 10}" y1="${Y(s)}" y2="${Y(s)}" stroke="${INK}" stroke-width="1.2"/>`;
    if (a.step >= 40) for (let s = 40; s <= a.step; s += 2) g += `<line x1="${a.cx - 10}" x2="${a.cx + 10}" y1="${Y(s)}" y2="${Y(s)}" stroke="${INK}" stroke-width="1.2"/>`;
    if (a.show) g += glyph(a.acc === 0 ? 0 : (a.acc >= 2 ? 2 : a.acc), a.cx - (Math.abs(a.acc) === 2 ? 15 : 12), a.y);
    if (a.d >= 4) g += `<ellipse cx="${a.cx}" cy="${a.y}" rx="7.4" ry="5" fill="none" stroke="currentColor" stroke-width="2.4"/>`;
    else if (a.d >= 2) g += `<ellipse cx="${a.cx}" cy="${a.y}" rx="6.4" ry="4.7" transform="rotate(-20 ${a.cx} ${a.y})" fill="none" stroke="currentColor" stroke-width="2.2"/>`;
    else g += `<ellipse cx="${a.cx}" cy="${a.y}" rx="6.4" ry="4.7" transform="rotate(-20 ${a.cx} ${a.y})" fill="currentColor"/>`;
    if (a.d < 4) {
      const dn = down[i], sx = dn ? a.cx - 5.7 : a.cx + 5.7;
      let tip = dn ? a.y + 33 : a.y - 33;
      if (pairOf[i]) { const b = it[pairOf[i].with]; tip = dn ? Math.max(a.y, b.y) + 33 : Math.min(a.y, b.y) - 33; }
      g += `<line x1="${sx}" x2="${sx}" y1="${a.y}" y2="${tip}" stroke="currentColor" stroke-width="1.5"/>`;
      if (pairOf[i] && pairOf[i].lead) {
        const b = it[pairOf[i].with], sx2 = dn ? b.cx - 5.7 : b.cx + 5.7, o = dn ? -5 : 5;
        beams += `<polygon points="${sx},${tip} ${sx2},${tip} ${sx2},${tip + o} ${sx},${tip + o}" fill="${INK}"/>`;
      }
      if (a.d === 0.5 && !pairOf[i]) {
        g += dn
          ? `<path d="M${sx} ${tip} c0 -9 10 -12 8 -24" transform="scale(1 -1) translate(0 ${-2 * tip})" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>`
          : `<path d="M${sx} ${tip} c0 9 11 12 8 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>`;
      }
    }
    if (a.d === 3 || a.d === 1.5) { const dy = ((a.step - 30) % 2 === 0) ? -5 : 0; g += `<circle cx="${a.cx + 11}" cy="${a.y + dy}" r="1.9" fill="currentColor"/>`; }
    p += g + '</g>';
  });
  p += beams;

  const W = L.endX + 16;
  root.querySelector('#sheet').innerHTML =
    `<svg width="${W * K}" height="${H * K}" viewBox="0 ${yMin} ${W} ${H}" role="img" aria-label="Escala escrita">${p}</svg>`;

  // clave + armadura + compás (fijos a la izquierda)
  let x = 34, c = '';
  const sg = L.sig;
  for (let i = 0; i < Math.abs(sg); i++) {
    c += glyph(sg > 0 ? 1 : -1, x + 5, Y(sg > 0 ? SHARP_STEPS[i] : FLAT_STEPS[i]));
    x += sg > 0 ? 10 : 9;
  }
  x += 6;
  const cw = x + 22;
  let lines = '';
  for (let i = 0; i < 5; i++) lines += `<line class="sline" x1="0" x2="${cw}" y1="${i * 10}" y2="${i * 10}"/>`;
  const ts = `<text x="${x + 8}" y="19" text-anchor="middle" font-size="25" font-weight="700" fill="#eaf0fb">4</text><text x="${x + 8}" y="39" text-anchor="middle" font-size="25" font-weight="700" fill="#eaf0fb">4</text>`;
  root.querySelector('#clefbox').innerHTML =
    `<svg width="${cw * K}" height="${H * K}" viewBox="0 ${yMin} ${cw} ${H}" aria-hidden="true"><g color="#eaf0fb">${lines}<g transform="translate(2 0)">${CLEF}</g>${c}${ts}</g></svg>`;

  return it;
}
