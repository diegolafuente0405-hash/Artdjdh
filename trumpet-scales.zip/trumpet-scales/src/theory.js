// Teoría musical pura (sin DOM). Notas escritas para trompeta en Si♭.
// Los números MIDI de aquí son los ESCRITOS; el sonido real es 2 semitonos más grave.

export const LET_PC = [0, 2, 4, 5, 7, 9, 11];
export const ES = ['Do', 'Re', 'Mi', 'Fa', 'Sol', 'La', 'Si'];
export const SOUND_NAMES = ['Do', 'Re♭', 'Re', 'Mi♭', 'Mi', 'Fa', 'Sol♭', 'Sol', 'La♭', 'La', 'Si♭', 'Si'];
export const MIN_LABELS = ['Do', 'Do♯', 'Re', 'Mi♭', 'Mi', 'Fa', 'Fa♯', 'Sol', 'Sol♯', 'La', 'Si♭', 'Si'];
export const MAJ_LABELS = ['Do', 'Re♭', 'Re', 'Mi♭', 'Mi', 'Fa', 'Fa♯', 'Sol', 'La♭', 'La', 'Si♭', 'Si'];

// pc -> [letra (Do=0..Si=6), alteración]
const MAJ_ROOTS = {0:[0,0],1:[1,-1],2:[1,0],3:[2,-1],4:[2,0],5:[3,0],6:[3,1],7:[4,0],8:[5,-1],9:[5,0],10:[6,-1],11:[6,0]};
const MIN_ROOTS = {0:[0,0],1:[0,1],2:[1,0],3:[2,-1],4:[2,0],5:[3,0],6:[3,1],7:[4,0],8:[4,1],9:[5,0],10:[6,-1],11:[6,0]};
const SIG_MAJ = {0:0,1:-5,2:2,3:-3,4:4,5:-1,6:6,7:1,8:-4,9:3,10:-2,11:5};
const SIG_MIN = {0:-3,1:4,2:-1,3:-6,4:1,5:-4,6:3,7:-2,8:5,9:0,10:-5,11:2};
const SH = [[0,0],[0,1],[1,0],[1,1],[2,0],[3,0],[3,1],[4,0],[4,1],[5,0],[5,1],[6,0]];
const FL = [[0,0],[1,-1],[1,0],[2,-1],[2,0],[3,0],[4,-1],[4,0],[5,-1],[5,0],[6,-1],[6,0]];
export const SHARP_ORDER = [3,0,4,1,5,2,6], SHARP_STEPS = [38,35,39,36,33,37,34];
export const FLAT_ORDER = [6,2,5,1,4,0,3], FLAT_STEPS = [34,37,33,36,32,35,31];
const PAT = {major:[0,2,4,5,7,9,11], minor:[0,2,3,5,7,8,10], harm:[0,2,3,5,7,8,11], mel:[0,2,3,5,7,9,11]};

export const RANGE = { low: 54, high: 88 }; // Fa♯3 a Mi6 escritos

export const isMinorish = (type) => ['minor', 'harm', 'mel', 'arpm'].includes(type);
export const accSymbol = (a) => a === 1 ? '♯' : a === -1 ? '♭' : a === 2 ? '♯♯' : a === -2 ? '♭♭' : '';
export const writtenName = (letter, acc, step) => ES[letter] + accSymbol(acc) + ' ' + Math.floor(step / 7);
export const soundName = (writtenMidi) => {
  const m = writtenMidi - 2;
  return SOUND_NAMES[((m % 12) + 12) % 12] + ' ' + (Math.floor(m / 12) - 1);
};

// Digitación (nota escrita): se elige el armónico con menos válvulas.
const PARTIALS = { 2:12, 3:19, 4:24, 5:28, 6:31, 8:36, 10:40 };
const COMBO = [[], [2], [1], [1,2], [2,3], [1,3], [1,2,3]];
export function fingering(w) {
  let best = null;
  for (const p in PARTIALS) {
    const k = 48 + PARTIALS[p] - w;
    if (k >= 0 && k <= 6 && (best === null || k < best)) best = k;
  }
  return COMBO[best === null ? 0 : best];
}

export function keySignature(s) {
  if (s.type === 'chrom') return 0;
  return isMinorish(s.type) ? SIG_MIN[s.pc] : SIG_MAJ[s.pc];
}

// Genera las notas de la escala: [{midi, step, letter, acc}]
export function buildNotes(s) {
  const [letter, racc] = (isMinorish(s.type) ? MIN_ROOTS : MAJ_ROOTS)[s.pc];
  let rm = RANGE.low;
  while (rm % 12 !== s.pc) rm++;
  if (String(s.hi) === '1') rm += 12;
  let n = +s.oct;
  while (rm + 12 * n > RANGE.high && n > 1) n--;
  while (rm + 12 * n > RANGE.high) rm -= 12;

  const oct0 = (rm - racc - LET_PC[letter]) / 12 - 1;
  const rootStep = oct0 * 7 + letter;
  const mk = (k, semis) => {
    const step = rootStep + k, l = ((step % 7) + 7) % 7, midi = rm + semis;
    return { midi, step, letter: l, acc: midi - (12 * (Math.floor(step / 7) + 1) + LET_PC[l]) };
  };
  const fromSpelling = (midi, sp) => {
    const [l, a] = sp;
    const oct = Math.floor((midi - a - LET_PC[l]) / 12) - 1;
    return { midi, step: oct * 7 + l, letter: l, acc: a };
  };

  let asc = [], desc = [];
  if (s.type === 'chrom') {
    const flats = [1, 3, 8, 10].includes(s.pc);
    for (let m = rm; m <= rm + 12 * n; m++) asc.push(fromSpelling(m, (flats ? FL : SH)[m % 12]));
    for (let m = rm + 12 * n - 1; m >= rm; m--) desc.push(fromSpelling(m, FL[m % 12]));
    if (desc.length) desc[desc.length - 1] = { ...asc[0] };
  } else if (s.type === 'arpM' || s.type === 'arpm') {
    const ap = [0, s.type === 'arpM' ? 4 : 3, 7], idx = { 0:0, 2:1, 4:2 };
    const ks = [];
    for (let o = 0; o < n; o++) ks.push(7 * o, 7 * o + 2, 7 * o + 4);
    ks.push(7 * n);
    asc = ks.map(k => mk(k, ap[idx[k % 7]] + 12 * Math.floor(k / 7)));
    desc = asc.slice(0, -1).reverse();
  } else {
    const pa = PAT[s.type], pd = s.type === 'mel' ? PAT.minor : pa;
    for (let k = 0; k <= 7 * n; k++) asc.push(mk(k, pa[k % 7] + 12 * Math.floor(k / 7)));
    for (let k = 7 * n - 1; k >= 0; k--) desc.push(mk(k, pd[k % 7] + 12 * Math.floor(k / 7)));
  }
  const peak = asc[asc.length - 1];
  if (s.dir === 'up') return asc;
  if (s.dir === 'down') return [peak, ...desc];
  return [...asc, ...desc];
}

// Posiciones horizontales, duraciones y alteraciones a mostrar.
export function layout(notes, s) {
  const u = s.fig === 'q' ? 1 : 0.5, n = notes.length;
  const durs = notes.map(() => u);
  const rem = 4 - (((n - 1) * u) % 4);
  durs[n - 1] = [4, 3, 2, 1.5, 1, 0.5].find(d => d <= rem + 1e-9);

  const sig = keySignature(s), keyAcc = {};
  if (sig > 0) for (let i = 0; i < sig; i++) keyAcc[SHARP_ORDER[i]] = 1;
  if (sig < 0) for (let i = 0; i < -sig; i++) keyAcc[FLAT_ORDER[i]] = -1;

  let state = {}, cursor = 14, beat = 0;
  const items = [], bars = [];
  notes.forEach((nt, i) => {
    const d = durs[i], id = nt.letter + '_' + Math.floor(nt.step / 7);
    const expected = state[id] !== undefined ? state[id] : (keyAcc[nt.letter] || 0);
    const show = nt.acc !== expected;
    state[id] = nt.acc;
    const accW = show ? (Math.abs(nt.acc) === 2 ? 17 : 14) : 0;
    const cx = cursor + accW + 10;
    items.push({ ...nt, d, start: beat, cx, show });
    cursor += accW + 24 + 24 * Math.min(d, 2) + 8 * Math.max(0, d - 2);
    beat += d;
    if (Math.abs(beat % 4) < 1e-9 && i < n - 1) { bars.push(cursor + 2); cursor += 12; state = {}; }
  });
  return { items, bars, endX: cursor + 4, total: beat, cycle: Math.ceil(beat / 4 - 1e-9) * 4, sig };
}
