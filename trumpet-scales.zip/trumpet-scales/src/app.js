// Interfaz y reproductor: une teoría, pentagrama y audio.
import { S } from './state.js';
import { buildNotes, layout, fingering, writtenName, soundName, isMinorish, MIN_LABELS, MAJ_LABELS } from './theory.js';
import { renderStaff, K } from './staff.js';
import { initAudio, playNote, click, stopAll, now } from './audio.js';

const $ = (s) => document.querySelector(s);
let song = { items: [], total: 0, cycle: 4 }, cur = -1;
const P = { playing: false, t0: 0, spb: 0.75, sb: 0, ci: 4, timer: 0, raf: 0 };
const timeOf = (b) => P.t0 + b * P.spb;

/* ---------- partitura ---------- */
function render() {
  const notes = buildNotes(S), L = layout(notes, S);
  const items = renderStaff(notes, L);
  song = { items, total: L.total, cycle: L.cycle };
  cur = -1; showIdle();
}

/* ---------- vista: pistones y lectura ---------- */
function pistons(f) {
  [1, 2, 3].forEach(n => {
    $('#p' + n).classList.toggle('down', f.includes(n));
    $('#n' + n).classList.toggle('lit', f.includes(n));
  });
}
function showIdle() {
  setCurrent(-1);
  document.querySelectorAll('#beats i').forEach(i => i.className = '');
  const a = song.items[0];
  $('#rnote').firstChild.nodeValue = a ? writtenName(a.letter, a.acc, a.step) : '';
  $('#rsound').textContent = a ? '· primera nota' : '';
  $('#rfing').innerHTML = 'Pulsa ▶ para empezar';
  pistons([]);
  $('#sheet').scrollLeft = 0;
}
function setCurrent(i) {
  if (i === cur) return;
  cur = i;
  document.querySelectorAll('.note').forEach((e, k) =>
    e.setAttribute('class', i < 0 ? 'note' : k < i ? 'note done' : k === i ? 'note on' : 'note'));
  if (i < 0) return;
  const a = song.items[i];
  $('#rnote').firstChild.nodeValue = writtenName(a.letter, a.acc, a.step);
  $('#rsound').textContent = '· suena ' + soundName(a.midi);
  const f = fingering(a.midi);
  pistons(f);
  $('#rfing').innerHTML = f.length ? 'Pistones <b>' + f.join(' · ') + '</b>' : '<b>Al aire</b> (sin pistones)';
}
function setPlayIcon(on) {
  $('#playicon').setAttribute('d', on ? 'M6 5h4.2v14H6zM13.8 5H18v14h-4.2z' : 'M7 4.5v15l13-7.5z');
  $('#play').setAttribute('aria-label', on ? 'Detener' : 'Reproducir');
}

/* ---------- reproductor ---------- */
function schedule() {
  const horizon = now() + 0.18;
  while (timeOf(P.sb) < horizon) {
    const b = P.sb;
    if (!S.loop && b >= song.cycle) { P.sb++; continue; }
    if (S.metro) click(timeOf(b), ((b % 4) + 4) % 4 === 0);
    if (b >= 0 && S.trumpet) {
      const c = Math.floor(b / song.cycle), local = b - c * song.cycle;
      song.items.forEach(a => {
        if (a.start >= local - 1e-9 && a.start < local + 1 - 1e-9)
          playNote(a.midi - 2, timeOf(b + (a.start - local)), a.d * P.spb);
      });
    }
    P.sb++;
  }
}
async function start() {
  if (P.playing) return;
  try { await initAudio(t => $('#msg').textContent = t); }
  catch (e) { $('#msg').textContent = 'No se pudo iniciar el audio en este navegador.'; return; }
  P.spb = 60 / S.bpm; P.ci = S.count ? 4 : 0;
  P.t0 = now() + 0.12 + P.ci * P.spb;
  P.sb = -P.ci; P.playing = true;
  setPlayIcon(true);
  P.timer = setInterval(schedule, 25); schedule();
  cancelAnimationFrame(P.raf); P.raf = requestAnimationFrame(frame);
}
function stop() {
  P.playing = false; clearInterval(P.timer); cancelAnimationFrame(P.raf);
  stopAll(); setPlayIcon(false); showIdle();
}
function frame() {
  if (!P.playing) return;
  const pos = (now() - P.t0) / P.spb;
  const bi = ((Math.floor(pos) % 4) + 4) % 4;
  document.querySelectorAll('#beats i').forEach((e, k) => e.className = k === bi ? ('on' + (k === 0 ? ' first' : '')) : '');
  if (pos < 0) {
    $('#rfing').innerHTML = 'Cuenta previa… <b>' + (Math.floor(pos) + P.ci + 1) + '</b>';
  } else if (!S.loop && pos >= song.cycle) {
    stop(); return;
  } else {
    const local = pos - Math.floor(pos / song.cycle) * song.cycle;
    const idx = song.items.findIndex(a => local >= a.start - 1e-6 && local < a.start + a.d);
    if (idx >= 0) {
      setCurrent(idx);
      const sh = $('#sheet'), target = song.items[idx].cx * K - sh.clientWidth * 0.4;
      sh.scrollLeft += (target - sh.scrollLeft) * 0.18;
    }
  }
  P.raf = requestAnimationFrame(frame);
}
function setBpm(v) {
  v = Math.max(40, Math.min(208, Math.round(v)));
  if (P.playing) { const pos = (now() - P.t0) / P.spb; P.spb = 60 / v; P.t0 = now() - pos * P.spb; }
  S.bpm = v; $('#bpm').value = v; $('#bpmv').textContent = v;
}

/* ---------- controles ---------- */
function fillRoots() {
  const minor = isMinorish(S.type), labels = minor ? MIN_LABELS : MAJ_LABELS;
  const suffix = minor ? ' menor' : (S.type === 'chrom' || S.type.startsWith('arp')) ? '' : ' mayor';
  $('#root').innerHTML = labels.map((t, i) => `<option value="${i}">${t}${suffix}</option>`).join('');
  $('#root').value = S.pc;
}
const refresh = () => { if (P.playing) stop(); render(); };

$('#type').onchange = e => { S.type = e.target.value; fillRoots(); refresh(); };
$('#root').onchange = e => { S.pc = +e.target.value; refresh(); };
document.querySelectorAll('.seg').forEach(seg => {
  const key = seg.dataset.key, btns = seg.querySelectorAll('button');
  const sync = () => btns.forEach(b => b.setAttribute('aria-pressed', String(String(S[key]) === b.dataset.v)));
  btns.forEach(b => b.onclick = () => { S[key] = key === 'oct' ? +b.dataset.v : b.dataset.v; sync(); refresh(); });
  sync();
});
function toggle(id, key) {
  const b = $(id);
  b.onclick = () => { S[key] = !S[key]; b.setAttribute('aria-pressed', String(S[key])); };
}
toggle('#tTrump', 'trumpet'); toggle('#tMetro', 'metro'); toggle('#tCount', 'count'); toggle('#tLoop', 'loop');
$('#play').onclick = () => P.playing ? stop() : start();
$('#bpm').oninput = e => setBpm(+e.target.value);
$('#bm').onclick = () => setBpm(S.bpm - 2);
$('#bp').onclick = () => setBpm(S.bpm + 2);

fillRoots(); render();

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  navigator.serviceWorker.register('sw.js').catch(() => {});
}
