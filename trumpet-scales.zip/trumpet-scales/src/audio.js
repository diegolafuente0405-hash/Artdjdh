// Audio: samples de trompeta + metrónomo con Web Audio.
// Los archivos samples/m<MIDI>.mp3 están a altura REAL (MIDI sonoro); faltan 54 y 66, que se
// generan cambiando la velocidad de la nota vecina.
const SAMPLE_MIDIS = [52,53,55,56,57,58,59,60,61,62,63,64,65,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88];

let ctx = null, master = null, ready = false;
const buffers = {};
const live = new Set();

export const isReady = () => ready;
export const now = () => ctx.currentTime;

export async function initAudio(onStatus = () => {}) {
  if (!ctx) {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -14; comp.ratio.value = 3;
    master = ctx.createGain(); master.gain.value = 0.9;
    // reverb sencilla con respuesta de ruido que decae
    const conv = ctx.createConvolver(), len = ctx.sampleRate * 1.1, ir = ctx.createBuffer(2, len, ctx.sampleRate);
    for (let c = 0; c < 2; c++) { const d = ir.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3.2); }
    conv.buffer = ir;
    const wet = ctx.createGain(); wet.gain.value = 0.16;
    master.connect(comp); master.connect(conv); conv.connect(wet); wet.connect(comp); comp.connect(ctx.destination);
  }
  if (ctx.state === 'suspended') await ctx.resume();
  if (!ready) {
    onStatus('Cargando sonidos…');
    await Promise.all(SAMPLE_MIDIS.map(async (m) => {
      const res = await fetch(`samples/m${m}.mp3`);
      const data = await res.arrayBuffer();
      buffers[m] = await new Promise((ok, fail) => ctx.decodeAudioData(data, ok, fail));
    }));
    ready = true; onStatus('');
  }
}

// m = MIDI sonoro, when = tiempo del contexto, dur = segundos
export function playNote(m, when, dur) {
  let best = null;
  for (const k in buffers) { const d = Math.abs(k - m); if (best === null || d < best.d) best = { k: +k, d }; }
  if (!best) return;
  const src = ctx.createBufferSource();
  src.buffer = buffers[best.k];
  src.playbackRate.value = Math.pow(2, (m - best.k) / 12);
  const g = ctx.createGain(), end = when + dur * 0.97;
  g.gain.setValueAtTime(0, when);
  g.gain.linearRampToValueAtTime(1, when + 0.02);
  g.gain.setValueAtTime(1, Math.max(when + 0.03, end - 0.07));
  g.gain.linearRampToValueAtTime(0, end + 0.04);
  const bd = src.buffer.duration / src.playbackRate.value;
  if (dur > bd - 0.2) { src.loop = true; src.loopStart = 0.5; src.loopEnd = 1.25; } // notas largas
  src.connect(g); g.connect(master);
  src.start(when); src.stop(end + 0.1);
  const o = { src, g }; live.add(o); src.onended = () => live.delete(o);
}

export function click(when, accent) {
  const o = ctx.createOscillator(), g = ctx.createGain();
  o.type = 'triangle'; o.frequency.value = accent ? 1568 : 1046;
  g.gain.setValueAtTime(0, when);
  g.gain.linearRampToValueAtTime(accent ? 0.55 : 0.38, when + 0.002);
  g.gain.exponentialRampToValueAtTime(0.001, when + 0.07);
  o.connect(g); g.connect(master); o.start(when); o.stop(when + 0.09);
}

export function stopAll() {
  if (!ctx) return;
  const t = ctx.currentTime;
  live.forEach(o => { try { o.g.gain.cancelScheduledValues(t); o.g.gain.setTargetAtTime(0, t, 0.02); o.src.stop(t + 0.12); } catch (e) {} });
}
