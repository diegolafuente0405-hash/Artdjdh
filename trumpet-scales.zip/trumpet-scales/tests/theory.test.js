import assert from 'node:assert/strict';
import { buildNotes, layout, fingering, keySignature, RANGE, writtenName } from '../src/theory.js';

const base = { type: 'major', pc: 0, dir: 'both', fig: 'q', oct: 1, hi: '0' };
const names = (s) => buildNotes(s).map(n => writtenName(n.letter, n.acc, n.step).replace(' ', ''));

// digitaciones de trompeta en Si♭ (notas escritas)
const F = (w) => fingering(w).join('');
assert.equal(F(60), '');       // Do4 al aire
assert.equal(F(61), '123');    // Do♯4
assert.equal(F(62), '13');     // Re4
assert.equal(F(64), '12');     // Mi4
assert.equal(F(65), '1');      // Fa4
assert.equal(F(67), '');       // Sol4 al aire
assert.equal(F(73), '12');     // Do♯5
assert.equal(F(76), '');       // Mi5 al aire
assert.equal(F(80), '23');     // Sol♯5
assert.equal(F(54), '123');    // Fa♯3, la más grave

// Do mayor: sube y baja 1 octava
assert.deepEqual(names(base), ['Do4','Re4','Mi4','Fa4','Sol4','La4','Si4','Do5','Si4','La4','Sol4','Fa4','Mi4','Re4','Do4']);
// Sol mayor: Fa♯ en la armadura
assert.equal(keySignature({ ...base, pc: 7 }), 1);
assert.deepEqual(names({ ...base, pc: 7, dir: 'up' }).slice(0, 8), ['Sol3','La3','Si3','Do4','Re4','Mi4','Fa♯4','Sol4']);
// La♭ mayor se escribe con bemoles
assert.deepEqual(names({ ...base, pc: 8, dir: 'up' }).slice(0, 4), ['La♭3','Si♭3','Do4','Re♭4']);
// menor melódica: baja con la escala natural
const mel = names({ ...base, type: 'mel', pc: 9 });
assert.deepEqual(mel.slice(5, 10), ['Fa♯4','Sol♯4','La4','Sol4','Fa4']);
// arpegio mayor de Do
assert.deepEqual(names({ ...base, type: 'arpM', dir: 'up' }), ['Do4','Mi4','Sol4','Do5']);

// todas las escalas, tonalidades y opciones caben en el rango y llenan compases
for (const type of ['major','minor','harm','mel','chrom','arpM','arpm'])
  for (let pc = 0; pc < 12; pc++)
    for (const dir of ['up','down','both'])
      for (const fig of ['q','e'])
        for (const oct of [1, 2])
          for (const hi of ['0','1']) {
            const s = { type, pc, dir, fig, oct, hi };
            const notes = buildNotes(s);
            for (const n of notes) assert.ok(n.midi >= RANGE.low && n.midi <= RANGE.high, `fuera de rango ${JSON.stringify(s)} ${n.midi}`);
            const L = layout(notes, s);
            assert.ok(L.cycle % 4 === 0 && L.cycle >= L.total, 'ciclo');
            const last = L.items.at(-1);
            assert.ok(last.start + last.d <= L.cycle + 1e-9);
          }
console.log('Todas las pruebas de teoría pasaron.');
